from distutils.core import setup
from setuptools import setup

setup(
        name         = 'nesterlist2017test',
        version      = '1.1.0',
        py_modules   = ['nesterlist2017test'],
        author       = 'johnson',
        author_email = '453713729@qq.com',
        url          = '',
        description  = 'A simple printer of nesterlist2017test',
    )

